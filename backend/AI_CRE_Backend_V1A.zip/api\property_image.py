from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.db.session import get_db
from app.services.property_image_service import property_image_service
from app.schemas import PropertyImageCreate, PropertyImageUpdate, PropertyImageResponse, PropertyImageListResponse
from pydantic import BaseModel

router = APIRouter()

class DeleteResponse(BaseModel):
    success: bool = True

@router.post("/", response_model=PropertyImageResponse, status_code=201)
def create_property_image(obj_in: PropertyImageCreate, db: Session = Depends(get_db)):
    return property_image_service.create_image(db, image_in=obj_in)

@router.get("/{id}", response_model=PropertyImageResponse)
def get_property_image(id: int, db: Session = Depends(get_db)):
    db_obj = property_image_service.get_image(db, id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Property image not found")
    return db_obj

@router.get("/", response_model=PropertyImageListResponse)
def list_property_images(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=500),
    property_id: Optional[int] = Query(None),
    project_id: Optional[str] = Query(None),
    image_type: Optional[str] = Query(None),
    include_deleted: bool = Query(False),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    items, total = property_image_service.get_images(
        db,
        skip=skip,
        limit=limit,
        property_id=property_id,
        project_id=project_id,
        image_type=image_type,
        include_deleted=include_deleted,
        search=search
    )
    return {"count": total, "items": items}

@router.put("/{id}", response_model=PropertyImageResponse)
def update_property_image(id: int, obj_in: PropertyImageUpdate, db: Session = Depends(get_db)):
    db_obj = property_image_service.get_image(db, id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Property image not found")
    return property_image_service.update_image(db, id=id, image_in=obj_in)

@router.delete("/{id}", response_model=DeleteResponse)
def delete_property_image(id: int, soft: bool = Query(True), db: Session = Depends(get_db)):
    db_obj = property_image_service.get_image(db, id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Property image not found")
    property_image_service.delete_image(db, id=id, soft=soft)
    return {"success": True}
